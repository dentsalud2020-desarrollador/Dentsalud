import { useState } from 'react';
import {
  Calendar,
  Clock,
  Phone,
  Mail,
  Users,
  Search,
  Plus,
  Smile,
  FileText,
  DollarSign,
  Home,
  User,
  LogOut,
  Save,
  Printer,
  Edit
} from 'lucide-react';
import { LogoDentSalud } from './components/LogoDentSalud';
import { FooterFicha } from './components/FooterFicha';

type View = 'dashboard' | 'pacientes' | 'nueva-cita' | 'nuevo-paciente' | 'historia-clinica' | 'odontograma' | 'presupuesto' | 'evolucion';

interface Paciente {
  id: number;
  dni: string;
  nombre: string;
  apellido: string;
  edad: number;
  telefono: string;
  correo: string;
  direccion: string;
  fechaNacimiento: string;
}

interface Cita {
  id: number;
  paciente: string;
  fecha: string;
  hora: string;
  motivo: string;
  estado: 'Pendiente' | 'Completada' | 'Cancelada';
}

interface Tratamiento {
  nombre: string;
  subcategorias?: string[];
  cantidad: number;
  precioUnitario: number;
}

interface EvolucionRegistro {
  fecha: string;
  tratamiento: string;
  importe: number;
  firma: string;
}

export default function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPaciente, setSelectedPaciente] = useState<Paciente | null>(null);

  // Catálogo de tratamientos según la ficha
  const catalogoTratamientos = [
    { nombre: 'PROFILAXIS', subcategorias: [] },
    { nombre: 'RESINAS', subcategorias: ['A', 'B', 'C', 'D', 'E'] },
    { nombre: 'CARILLAS', subcategorias: ['R', 'P'] },
    { nombre: 'ENDODONCIA', subcategorias: ['A', 'P'] },
    { nombre: 'PERNOS', subcategorias: ['C', 'Pr'] },
    { nombre: 'EXODONCIAS', subcategorias: ['S', 'C', 'T'] },
    { nombre: 'CORONAS', subcategorias: ['M', 'I', 'P'] },
    { nombre: 'PRÓTESIS', subcategorias: ['F', 'T', 'P'] },
    { nombre: 'BLANQUEAMIENTO', subcategorias: [] },
    { nombre: 'DISEÑO DE SONRISA', subcategorias: [] },
    { nombre: 'SELLANTES', subcategorias: [] },
    { nombre: 'ORTODONCIA', subcategorias: [] },
    { nombre: 'BICHECTOMÍA', subcategorias: [] },
    { nombre: 'RECUBRIMIENTO PULPAR', subcategorias: [] },
    { nombre: 'GINGIVECTOMÍA', subcategorias: [] },
    { nombre: 'INCRUSTACIÓN', subcategorias: [] },
    { nombre: 'IMPLANTES', subcategorias: [] },
    { nombre: 'APICECTOMÍA', subcategorias: [] },
    { nombre: 'BOTOX', subcategorias: [] },
    { nombre: 'ÁCIDO HIALURÓNICO', subcategorias: [] },
    { nombre: 'OTROS', subcategorias: [] }
  ];

  // Datos de ejemplo - 50 pacientes
  const [pacientes, setPacientes] = useState<Paciente[]>([
    { id: 1, dni: '12345678', nombre: 'Juan', apellido: 'Pérez', edad: 35, telefono: '999888777', correo: 'juan.perez@email.com', direccion: 'Av. Los Pinos 123, Trujillo', fechaNacimiento: '1991-01-15' },
    { id: 2, dni: '87654321', nombre: 'María', apellido: 'García', edad: 28, telefono: '988777666', correo: 'maria.garcia@email.com', direccion: 'Jr. Las Flores 456, Trujillo', fechaNacimiento: '1998-06-20' },
    { id: 3, dni: '45678912', nombre: 'Carlos', apellido: 'Rodríguez', edad: 42, telefono: '987654321', correo: 'carlos.rodriguez@email.com', direccion: 'Calle San Martín 789, Trujillo', fechaNacimiento: '1984-03-10' },
    { id: 4, dni: '78945612', nombre: 'Ana', apellido: 'López', edad: 25, telefono: '976543210', correo: 'ana.lopez@email.com', direccion: 'Av. España 234, Trujillo', fechaNacimiento: '2001-09-15' },
    { id: 5, dni: '32165498', nombre: 'Roberto', apellido: 'Sánchez', edad: 55, telefono: '965432109', correo: 'roberto.sanchez@email.com', direccion: 'Jr. Bolívar 567, Trujillo', fechaNacimiento: '1971-11-28' },
    { id: 6, dni: '65498732', nombre: 'Lucía', apellido: 'Torres', edad: 31, telefono: '954321098', correo: 'lucia.torres@email.com', direccion: 'Av. América 890, Trujillo', fechaNacimiento: '1995-07-03' },
    { id: 7, dni: '98732165', nombre: 'Pedro', apellido: 'Ramírez', edad: 48, telefono: '943210987', correo: 'pedro.ramirez@email.com', direccion: 'Calle Independencia 345, Trujillo', fechaNacimiento: '1978-02-17' },
    { id: 8, dni: '15975346', nombre: 'Carmen', apellido: 'Flores', edad: 38, telefono: '932109876', correo: 'carmen.flores@email.com', direccion: 'Jr. Grau 678, Trujillo', fechaNacimiento: '1988-05-22' },
    { id: 9, dni: '75395128', nombre: 'Jorge', apellido: 'Castillo', edad: 29, telefono: '921098765', correo: 'jorge.castillo@email.com', direccion: 'Av. Larco 912, Trujillo', fechaNacimiento: '1997-12-08' },
    { id: 10, dni: '35795146', nombre: 'Sofia', apellido: 'Mendoza', edad: 33, telefono: '910987654', correo: 'sofia.mendoza@email.com', direccion: 'Calle Orbegoso 123, Trujillo', fechaNacimiento: '1993-04-30' },
    { id: 11, dni: '46825379', nombre: 'Luis', apellido: 'Vega', edad: 45, telefono: '998765432', correo: 'luis.vega@email.com', direccion: 'Av. Mansiche 567, Trujillo', fechaNacimiento: '1981-08-12' },
    { id: 12, dni: '15935746', nombre: 'Patricia', apellido: 'Morales', edad: 27, telefono: '987456321', correo: 'patricia.morales@email.com', direccion: 'Jr. Pizarro 234, Trujillo', fechaNacimiento: '1999-03-25' },
    { id: 13, dni: '75315926', nombre: 'Diego', apellido: 'Herrera', edad: 39, telefono: '976345210', correo: 'diego.herrera@email.com', direccion: 'Calle Junín 890, Trujillo', fechaNacimiento: '1987-11-08' },
    { id: 14, dni: '95175346', nombre: 'Elena', apellido: 'Castro', edad: 32, telefono: '965234109', correo: 'elena.castro@email.com', direccion: 'Av. La Marina 456, Trujillo', fechaNacimiento: '1994-07-19' },
    { id: 15, dni: '35715928', nombre: 'Fernando', apellido: 'Ruiz', edad: 51, telefono: '954123098', correo: 'fernando.ruiz@email.com', direccion: 'Jr. Ayacucho 789, Trujillo', fechaNacimiento: '1975-01-30' },
    { id: 16, dni: '85236914', nombre: 'Gabriela', apellido: 'Paredes', edad: 26, telefono: '943012987', correo: 'gabriela.paredes@email.com', direccion: 'Av. Fátima 123, Trujillo', fechaNacimiento: '2000-05-14' },
    { id: 17, dni: '74185296', nombre: 'Miguel', apellido: 'Cortez', edad: 44, telefono: '932901876', correo: 'miguel.cortez@email.com', direccion: 'Calle Colón 345, Trujillo', fechaNacimiento: '1982-09-22' },
    { id: 18, dni: '25896374', nombre: 'Rosa', apellido: 'Navarro', edad: 37, telefono: '921890765', correo: 'rosa.navarro@email.com', direccion: 'Jr. San Andrés 678, Trujillo', fechaNacimiento: '1989-02-11' },
    { id: 19, dni: '96385274', nombre: 'Raúl', apellido: 'Medina', edad: 30, telefono: '910789654', correo: 'raul.medina@email.com', direccion: 'Av. El Golf 234, Trujillo', fechaNacimiento: '1996-12-03' },
    { id: 20, dni: '14725836', nombre: 'Valentina', apellido: 'Guzmán', edad: 34, telefono: '999678543', correo: 'valentina.guzman@email.com', direccion: 'Calle Los Olivos 567, Trujillo', fechaNacimiento: '1992-06-28' },
    { id: 21, dni: '36925814', nombre: 'Andrés', apellido: 'Silva', edad: 41, telefono: '988567432', correo: 'andres.silva@email.com', direccion: 'Av. Los Jardines 890, Trujillo', fechaNacimiento: '1985-10-15' },
    { id: 22, dni: '85296374', nombre: 'Carolina', apellido: 'Campos', edad: 29, telefono: '977456321', correo: 'carolina.campos@email.com', direccion: 'Jr. Los Sauces 123, Trujillo', fechaNacimiento: '1997-04-07' },
    { id: 23, dni: '74125836', nombre: 'Ricardo', apellido: 'Reyes', edad: 47, telefono: '966345210', correo: 'ricardo.reyes@email.com', direccion: 'Calle Las Palmeras 456, Trujillo', fechaNacimiento: '1979-08-20' },
    { id: 24, dni: '95184726', nombre: 'Daniela', apellido: 'Vargas', edad: 24, telefono: '955234109', correo: 'daniela.vargas@email.com', direccion: 'Av. Los Pinos 789, Trujillo', fechaNacimiento: '2002-01-18' },
    { id: 25, dni: '35796482', nombre: 'Héctor', apellido: 'Ortiz', edad: 53, telefono: '944123098', correo: 'hector.ortiz@email.com', direccion: 'Jr. Las Camelias 234, Trujillo', fechaNacimiento: '1973-07-05' },
    { id: 26, dni: '15982736', nombre: 'Isabel', apellido: 'Chávez', edad: 36, telefono: '933012987', correo: 'isabel.chavez@email.com', direccion: 'Calle Los Cedros 567, Trujillo', fechaNacimiento: '1990-11-12' },
    { id: 27, dni: '75392684', nombre: 'Javier', apellido: 'Romero', edad: 40, telefono: '922901876', correo: 'javier.romero@email.com', direccion: 'Av. Las Magnolias 890, Trujillo', fechaNacimiento: '1986-03-29' },
    { id: 28, dni: '85274196', nombre: 'Mónica', apellido: 'Peña', edad: 31, telefono: '911890765', correo: 'monica.pena@email.com', direccion: 'Jr. Los Jazmines 123, Trujillo', fechaNacimiento: '1995-09-16' },
    { id: 29, dni: '95173826', nombre: 'Sergio', apellido: 'Ríos', edad: 43, telefono: '990789654', correo: 'sergio.rios@email.com', direccion: 'Calle Las Rosas 456, Trujillo', fechaNacimiento: '1983-05-24' },
    { id: 30, dni: '35826947', nombre: 'Laura', apellido: 'Aguilar', edad: 28, telefono: '989678543', correo: 'laura.aguilar@email.com', direccion: 'Av. Los Tulipanes 789, Trujillo', fechaNacimiento: '1998-12-10' },
    { id: 31, dni: '75384926', nombre: 'Alberto', apellido: 'Carrillo', edad: 49, telefono: '978567432', correo: 'alberto.carrillo@email.com', direccion: 'Jr. Las Orquídeas 234, Trujillo', fechaNacimiento: '1977-02-22' },
    { id: 32, dni: '25896417', nombre: 'Beatriz', apellido: 'Ibarra', edad: 27, telefono: '967456321', correo: 'beatriz.ibarra@email.com', direccion: 'Calle Los Girasoles 567, Trujillo', fechaNacimiento: '1999-08-14' },
    { id: 33, dni: '85273946', nombre: 'Gustavo', apellido: 'Salazar', edad: 46, telefono: '956345210', correo: 'gustavo.salazar@email.com', direccion: 'Av. Las Violetas 890, Trujillo', fechaNacimiento: '1980-06-01' },
    { id: 34, dni: '15973684', nombre: 'Natalia', apellido: 'Mora', edad: 23, telefono: '945234109', correo: 'natalia.mora@email.com', direccion: 'Jr. Los Claveles 123, Trujillo', fechaNacimiento: '2003-10-27' },
    { id: 35, dni: '35794826', nombre: 'Rodrigo', apellido: 'Espinoza', edad: 52, telefono: '934123098', correo: 'rodrigo.espinoza@email.com', direccion: 'Calle Las Azucenas 456, Trujillo', fechaNacimiento: '1974-04-13' },
    { id: 36, dni: '95172836', nombre: 'Claudia', apellido: 'Benítez', edad: 35, telefono: '923012987', correo: 'claudia.benitez@email.com', direccion: 'Av. Los Lirios 789, Trujillo', fechaNacimiento: '1991-01-19' },
    { id: 37, dni: '75396428', nombre: 'Víctor', apellido: 'León', edad: 38, telefono: '912901876', correo: 'victor.leon@email.com', direccion: 'Jr. Las Dalias 234, Trujillo', fechaNacimiento: '1988-07-06' },
    { id: 38, dni: '15982647', nombre: 'Verónica', apellido: 'Montoya', edad: 30, telefono: '991890765', correo: 'veronica.montoya@email.com', direccion: 'Calle Los Nardos 567, Trujillo', fechaNacimiento: '1996-03-23' },
    { id: 39, dni: '85274639', nombre: 'Óscar', apellido: 'Palacios', edad: 44, telefono: '980789654', correo: 'oscar.palacios@email.com', direccion: 'Av. Las Hortensias 890, Trujillo', fechaNacimiento: '1982-11-30' },
    { id: 40, dni: '35791846', nombre: 'Silvia', apellido: 'Sandoval', edad: 26, telefono: '979678543', correo: 'silvia.sandoval@email.com', direccion: 'Jr. Los Geranios 123, Trujillo', fechaNacimiento: '2000-09-08' },
    { id: 41, dni: '95173648', nombre: 'Eduardo', apellido: 'Figueroa', edad: 50, telefono: '968567432', correo: 'eduardo.figueroa@email.com', direccion: 'Calle Las Begonias 456, Trujillo', fechaNacimiento: '1976-05-17' },
    { id: 42, dni: '75382946', nombre: 'Adriana', apellido: 'Delgado', edad: 32, telefono: '957456321', correo: 'adriana.delgado@email.com', direccion: 'Av. Los Pensamientos 789, Trujillo', fechaNacimiento: '1994-12-25' },
    { id: 43, dni: '25896374', nombre: 'Martín', apellido: 'Cabrera', edad: 41, telefono: '946345210', correo: 'martin.cabrera@email.com', direccion: 'Jr. Las Gardenias 234, Trujillo', fechaNacimiento: '1985-08-02' },
    { id: 44, dni: '85271946', nombre: 'Lorena', apellido: 'Valdez', edad: 29, telefono: '935234109', correo: 'lorena.valdez@email.com', direccion: 'Calle Los Helechos 567, Trujillo', fechaNacimiento: '1997-02-14' },
    { id: 45, dni: '15973826', nombre: 'Iván', apellido: 'Cordero', edad: 47, telefono: '924123098', correo: 'ivan.cordero@email.com', direccion: 'Av. Las Petunias 890, Trujillo', fechaNacimiento: '1979-10-21' },
    { id: 46, dni: '35794682', nombre: 'Paulina', apellido: 'Fuentes', edad: 25, telefono: '913012987', correo: 'paulina.fuentes@email.com', direccion: 'Jr. Los Arrayanes 123, Trujillo', fechaNacimiento: '2001-06-09' },
    { id: 47, dni: '95172684', nombre: 'Arturo', apellido: 'Solís', edad: 54, telefono: '992901876', correo: 'arturo.solis@email.com', direccion: 'Calle Las Calas 456, Trujillo', fechaNacimiento: '1972-01-28' },
    { id: 48, dni: '75391826', nombre: 'Mariana', apellido: 'Bravo', edad: 33, telefono: '981890765', correo: 'mariana.bravo@email.com', direccion: 'Av. Los Gladiolos 789, Trujillo', fechaNacimiento: '1993-09-05' },
    { id: 49, dni: '15982736', nombre: 'Guillermo', apellido: 'Maldonado', edad: 39, telefono: '970789654', correo: 'guillermo.maldonado@email.com', direccion: 'Jr. Las Amapolas 234, Trujillo', fechaNacimiento: '1987-05-12' },
    { id: 50, dni: '85274936', nombre: 'Cecilia', apellido: 'Huerta', edad: 31, telefono: '969678543', correo: 'cecilia.huerta@email.com', direccion: 'Calle Los Crisantemos 567, Trujillo', fechaNacimiento: '1995-11-20' }
  ]);

  const [tratamientosPresupuesto, setTratamientosPresupuesto] = useState<Tratamiento[]>([
    { nombre: 'PROFILAXIS', cantidad: 1, precioUnitario: 80 },
    { nombre: 'RESINAS', cantidad: 3, precioUnitario: 120 },
    { nombre: 'BLANQUEAMIENTO', cantidad: 1, precioUnitario: 350 }
  ]);

  const [evolucionPaciente, setEvolucionPaciente] = useState<EvolucionRegistro[]>([
    {
      fecha: '2026-06-01',
      tratamiento: 'Evaluación inicial y profilaxis',
      importe: 80,
      firma: 'Dr. Miler'
    },
    {
      fecha: '2026-06-05',
      tratamiento: 'Resina dental pieza 11',
      importe: 120,
      firma: 'Dr. Miler'
    },
    {
      fecha: '2026-06-07',
      tratamiento: 'Resina dental pieza 21',
      importe: 120,
      firma: 'Dr. Miler'
    }
  ]);

  const [nuevoRegistroEvolucion, setNuevoRegistroEvolucion] = useState({
    fecha: '',
    tratamiento: '',
    importe: '',
    firma: 'Dr. Miler'
  });

  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [diagnosticoOdontograma, setDiagnosticoOdontograma] = useState('');

  const [citas, setCitas] = useState<Cita[]>([
    // Citas HOY (2026-06-08) - Pendientes
    { id: 1, paciente: 'Juan Pérez', fecha: '2026-06-08', hora: '09:00', motivo: 'Control de rutina', estado: 'Pendiente' },
    { id: 2, paciente: 'María García', fecha: '2026-06-08', hora: '10:00', motivo: 'Limpieza dental y blanqueamiento', estado: 'Pendiente' },
    { id: 3, paciente: 'Carlos Rodríguez', fecha: '2026-06-08', hora: '11:00', motivo: 'Endodoncia pieza 16', estado: 'Pendiente' },
    { id: 4, paciente: 'Ana López', fecha: '2026-06-08', hora: '14:00', motivo: 'Colocación de brackets', estado: 'Pendiente' },
    { id: 5, paciente: 'Roberto Sánchez', fecha: '2026-06-08', hora: '15:00', motivo: 'Extracción de cordal', estado: 'Pendiente' },
    { id: 6, paciente: 'Lucía Torres', fecha: '2026-06-08', hora: '16:00', motivo: 'Resina dental pieza 11', estado: 'Pendiente' },

    // Citas Mañana (2026-06-09) - Pendientes
    { id: 7, paciente: 'Pedro Ramírez', fecha: '2026-06-09', hora: '09:00', motivo: 'Corona porcelana pieza 26', estado: 'Pendiente' },
    { id: 8, paciente: 'Carmen Flores', fecha: '2026-06-09', hora: '10:00', motivo: 'Control de ortodoncia', estado: 'Pendiente' },
    { id: 9, paciente: 'Jorge Castillo', fecha: '2026-06-09', hora: '11:00', motivo: 'Profilaxis', estado: 'Pendiente' },
    { id: 10, paciente: 'Sofia Mendoza', fecha: '2026-06-09', hora: '14:00', motivo: 'Blanqueamiento dental', estado: 'Pendiente' },
    { id: 11, paciente: 'Luis Vega', fecha: '2026-06-09', hora: '15:00', motivo: 'Extracción pieza 18', estado: 'Pendiente' },
    { id: 12, paciente: 'Patricia Morales', fecha: '2026-06-09', hora: '16:00', motivo: 'Resinas múltiples', estado: 'Pendiente' },

    // Próxima semana (2026-06-10)
    { id: 13, paciente: 'Diego Herrera', fecha: '2026-06-10', hora: '09:00', motivo: 'Limpieza dental', estado: 'Pendiente' },
    { id: 14, paciente: 'Elena Castro', fecha: '2026-06-10', hora: '10:00', motivo: 'Endodoncia pieza 36', estado: 'Pendiente' },
    { id: 15, paciente: 'Fernando Ruiz', fecha: '2026-06-10', hora: '11:00', motivo: 'Prótesis dental superior', estado: 'Pendiente' },
    { id: 16, paciente: 'Gabriela Paredes', fecha: '2026-06-10', hora: '14:00', motivo: 'Evaluación ortodóncica', estado: 'Pendiente' },
    { id: 17, paciente: 'Miguel Cortez', fecha: '2026-06-10', hora: '15:00', motivo: 'Implante dental pieza 46', estado: 'Pendiente' },

    // Próxima semana (2026-06-11)
    { id: 18, paciente: 'Rosa Navarro', fecha: '2026-06-11', hora: '09:00', motivo: 'Control post-operatorio', estado: 'Pendiente' },
    { id: 19, paciente: 'Raúl Medina', fecha: '2026-06-11', hora: '10:00', motivo: 'Sellantes dentales', estado: 'Pendiente' },
    { id: 20, paciente: 'Valentina Guzmán', fecha: '2026-06-11', hora: '11:00', motivo: 'Carillas de porcelana', estado: 'Pendiente' },
    { id: 21, paciente: 'Andrés Silva', fecha: '2026-06-11', hora: '14:00', motivo: 'Ajuste de prótesis', estado: 'Pendiente' },
    { id: 22, paciente: 'Carolina Campos', fecha: '2026-06-11', hora: '15:00', motivo: 'Diseño de sonrisa', estado: 'Pendiente' },

    // Próxima semana (2026-06-12)
    { id: 23, paciente: 'Ricardo Reyes', fecha: '2026-06-12', hora: '09:00', motivo: 'Limpieza profunda', estado: 'Pendiente' },
    { id: 24, paciente: 'Daniela Vargas', fecha: '2026-06-12', hora: '10:00', motivo: 'Primera consulta', estado: 'Pendiente' },
    { id: 25, paciente: 'Héctor Ortiz', fecha: '2026-06-12', hora: '11:00', motivo: 'Corona metal-porcelana', estado: 'Pendiente' },
    { id: 26, paciente: 'Isabel Chávez', fecha: '2026-06-12', hora: '14:00', motivo: 'Tratamiento de conducto', estado: 'Pendiente' },
    { id: 27, paciente: 'Javier Romero', fecha: '2026-06-12', hora: '15:00', motivo: 'Extracción simple', estado: 'Pendiente' },

    // Citas Completadas - Última semana
    { id: 28, paciente: 'Mónica Peña', fecha: '2026-06-07', hora: '09:00', motivo: 'Limpieza dental', estado: 'Completada' },
    { id: 29, paciente: 'Sergio Ríos', fecha: '2026-06-07', hora: '10:00', motivo: 'Resina pieza 21', estado: 'Completada' },
    { id: 30, paciente: 'Laura Aguilar', fecha: '2026-06-07', hora: '11:00', motivo: 'Control ortodóncico', estado: 'Completada' },
    { id: 31, paciente: 'Alberto Carrillo', fecha: '2026-06-07', hora: '14:00', motivo: 'Endodoncia pieza 26', estado: 'Completada' },
    { id: 32, paciente: 'Beatriz Ibarra', fecha: '2026-06-07', hora: '15:00', motivo: 'Blanqueamiento', estado: 'Completada' },

    { id: 33, paciente: 'Gustavo Salazar', fecha: '2026-06-06', hora: '09:00', motivo: 'Evaluación inicial', estado: 'Completada' },
    { id: 34, paciente: 'Natalia Mora', fecha: '2026-06-06', hora: '10:00', motivo: 'Profilaxis', estado: 'Completada' },
    { id: 35, paciente: 'Rodrigo Espinoza', fecha: '2026-06-06', hora: '11:00', motivo: 'Prótesis parcial', estado: 'Completada' },
    { id: 36, paciente: 'Claudia Benítez', fecha: '2026-06-06', hora: '14:00', motivo: 'Resinas múltiples', estado: 'Completada' },
    { id: 37, paciente: 'Víctor León', fecha: '2026-06-06', hora: '15:00', motivo: 'Extracción cordal', estado: 'Completada' },

    { id: 38, paciente: 'Verónica Montoya', fecha: '2026-06-05', hora: '09:00', motivo: 'Consulta de valoración', estado: 'Completada' },
    { id: 39, paciente: 'Óscar Palacios', fecha: '2026-06-05', hora: '10:00', motivo: 'Corona dental', estado: 'Completada' },
    { id: 40, paciente: 'Silvia Sandoval', fecha: '2026-06-05', hora: '11:00', motivo: 'Ortodoncia inicial', estado: 'Completada' },
    { id: 41, paciente: 'Eduardo Figueroa', fecha: '2026-06-05', hora: '14:00', motivo: 'Implante dental', estado: 'Completada' },
    { id: 42, paciente: 'Adriana Delgado', fecha: '2026-06-05', hora: '15:00', motivo: 'Limpieza profunda', estado: 'Completada' },

    { id: 43, paciente: 'Martín Cabrera', fecha: '2026-06-04', hora: '09:00', motivo: 'Resina estética', estado: 'Completada' },
    { id: 44, paciente: 'Lorena Valdez', fecha: '2026-06-04', hora: '10:00', motivo: 'Control rutinario', estado: 'Completada' },
    { id: 45, paciente: 'Iván Cordero', fecha: '2026-06-04', hora: '11:00', motivo: 'Endodoncia', estado: 'Completada' },
    { id: 46, paciente: 'Paulina Fuentes', fecha: '2026-06-04', hora: '14:00', motivo: 'Evaluación inicial', estado: 'Completada' },
    { id: 47, paciente: 'Arturo Solís', fecha: '2026-06-04', hora: '15:00', motivo: 'Ajuste de dentadura', estado: 'Completada' },

    { id: 48, paciente: 'Mariana Bravo', fecha: '2026-06-03', hora: '09:00', motivo: 'Profilaxis', estado: 'Completada' },
    { id: 49, paciente: 'Guillermo Maldonado', fecha: '2026-06-03', hora: '10:00', motivo: 'Extracción simple', estado: 'Completada' },
    { id: 50, paciente: 'Cecilia Huerta', fecha: '2026-06-03', hora: '11:00', motivo: 'Blanqueamiento dental', estado: 'Completada' },
    { id: 51, paciente: 'Juan Pérez', fecha: '2026-06-03', hora: '14:00', motivo: 'Resina compuesta', estado: 'Completada' },
    { id: 52, paciente: 'María García', fecha: '2026-06-03', hora: '15:00', motivo: 'Control post-tratamiento', estado: 'Completada' }
  ]);

  const [nuevoPaciente, setNuevoPaciente] = useState({
    dni: '',
    nombre: '',
    apellido: '',
    fechaNacimiento: '',
    edad: '',
    telefono: '',
    correo: '',
    direccion: ''
  });

  const [historiaClinica, setHistoriaClinica] = useState({
    numeroHistoria: 'HC-2026-001',
    fechaApertura: '2026-06-01',
    motivoConsulta: 'Dolor en pieza dental posterior derecha, sensibilidad al frío',
    patologicos: 'Hipertensión arterial controlada con medicación',
    gestante: 'NO',
    semanasGestacion: '',
    farmacologicos: 'Losartán 50mg - 1 tableta diaria',
    alergias: 'Penicilina (rash cutáneo)',
    cuello: 'Sin alteraciones',
    atm: 'Apertura normal, sin crepitación',
    mucosaYugal: 'Rosada, hidratada',
    paladar: 'Íntegro, sin lesiones',
    lengua: 'Normal, papilas conservadas',
    pisoBoca: 'Sin alteraciones',
    gingiva: 'Leve inflamación en sector posterior',
    analisisOclusion: 'Clase I, mordida normal'
  });

  const [nuevaCita, setNuevaCita] = useState({
    pacienteId: '',
    fecha: '',
    hora: '',
    motivo: ''
  });

  const handleCrearPaciente = (e: React.FormEvent) => {
    e.preventDefault();
    const paciente: Paciente = {
      id: pacientes.length + 1,
      dni: nuevoPaciente.dni,
      nombre: nuevoPaciente.nombre,
      apellido: nuevoPaciente.apellido,
      fechaNacimiento: nuevoPaciente.fechaNacimiento,
      edad: parseInt(nuevoPaciente.edad),
      telefono: nuevoPaciente.telefono,
      correo: nuevoPaciente.correo,
      direccion: nuevoPaciente.direccion
    };
    setPacientes([...pacientes, paciente]);
    setNuevoPaciente({
      dni: '',
      nombre: '',
      apellido: '',
      fechaNacimiento: '',
      edad: '',
      telefono: '',
      correo: '',
      direccion: ''
    });
    alert('Paciente registrado exitosamente');
    setCurrentView('pacientes');
  };

  const handleCrearCita = (e: React.FormEvent) => {
    e.preventDefault();
    const paciente = pacientes.find(p => p.id === parseInt(nuevaCita.pacienteId));
    if (paciente) {
      const cita: Cita = {
        id: citas.length + 1,
        paciente: `${paciente.nombre} ${paciente.apellido}`,
        fecha: nuevaCita.fecha,
        hora: nuevaCita.hora,
        motivo: nuevaCita.motivo,
        estado: 'Pendiente'
      };
      setCitas([...citas, cita]);
      setNuevaCita({
        pacienteId: '',
        fecha: '',
        hora: '',
        motivo: ''
      });
      alert('Cita agendada exitosamente');
      setCurrentView('dashboard');
    }
  };

  const handleGuardarHistoriaClinica = () => {
    alert('Historia Clínica guardada exitosamente');
  };

  const handleGuardarOdontograma = () => {
    alert('Odontograma guardado exitosamente');
  };

  const handleGuardarPresupuesto = () => {
    alert('Presupuesto guardado exitosamente');
  };

  const handleImprimirHistoria = () => {
    window.print();
  };

  const handleImprimirOdontograma = () => {
    window.print();
  };

  const handleImprimirPresupuesto = () => {
    window.print();
  };

  const handleImprimirEvolucion = () => {
    window.print();
  };

  const renderDashboard = () => {
    const hoy = '2026-06-08'; // Fecha actual del sistema
    const citasHoy = citas.filter(c => c.fecha === hoy);
    const citasPendientesHoy = citasHoy.filter(c => c.estado === 'Pendiente');
    const citasCompletadas = citas.filter(c => c.estado === 'Completada');

    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-2">Bienvenido, Dr. Miler</h2>
          <p className="text-blue-100">Hoy es {new Date(hoy).toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Pacientes</p>
                <p className="text-3xl font-bold text-gray-900">{pacientes.length}</p>
              </div>
              <Users className="w-12 h-12 text-blue-600" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Citas Hoy</p>
                <p className="text-3xl font-bold text-gray-900">{citasPendientesHoy.length}</p>
              </div>
              <Calendar className="w-12 h-12 text-green-600" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Citas Completadas</p>
                <p className="text-3xl font-bold text-gray-900">{citasCompletadas.length}</p>
              </div>
              <FileText className="w-12 h-12 text-purple-600" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Citas</p>
                <p className="text-3xl font-bold text-gray-900">{citas.length}</p>
              </div>
              <Clock className="w-12 h-12 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">Agenda del Día - {hoy}</h2>
            <span className="text-sm text-gray-500">{citasHoy.length} citas programadas</span>
          </div>
          <div className="p-6">
            {citasHoy.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No hay citas programadas para hoy</p>
            ) : (
              <div className="space-y-4">
                {citasHoy.map((cita) => (
                <div key={cita.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <Clock className="w-8 h-8 text-blue-600" />
                    <div>
                      <p className="font-medium text-gray-900">{cita.paciente}</p>
                      <p className="text-sm text-gray-500">{cita.motivo}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{cita.hora}</p>
                    <span className={`text-xs px-2 py-1 rounded ${
                      cita.estado === 'Pendiente' ? 'bg-yellow-100 text-yellow-800' :
                      cita.estado === 'Completada' ? 'bg-green-100 text-green-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {cita.estado}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
    );
  };

  const renderPacientes = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-900">Lista de Pacientes</h2>
          <button
            onClick={() => setCurrentView('nuevo-paciente')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Nuevo Paciente</span>
          </button>
        </div>

        <div className="p-6">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Buscar por DNI o nombre..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">DNI</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nombre</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Edad</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Teléfono</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {pacientes
                  .filter(p =>
                    p.dni.includes(searchTerm) ||
                    p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    p.apellido.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .map((paciente) => (
                    <tr key={paciente.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{paciente.dni}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {paciente.nombre} {paciente.apellido}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{paciente.edad}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{paciente.telefono}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                        <button
                          onClick={() => {
                            setSelectedPaciente(paciente);
                            setCurrentView('historia-clinica');
                          }}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Historia
                        </button>
                        <button
                          onClick={() => {
                            setSelectedPaciente(paciente);
                            setCurrentView('odontograma');
                          }}
                          className="text-green-600 hover:text-green-800"
                        >
                          Odontograma
                        </button>
                        <button
                          onClick={() => {
                            setSelectedPaciente(paciente);
                            setCurrentView('presupuesto');
                          }}
                          className="text-purple-600 hover:text-purple-800"
                        >
                          Presupuesto
                        </button>
                        <button
                          onClick={() => {
                            setSelectedPaciente(paciente);
                            setCurrentView('evolucion');
                          }}
                          className="text-orange-600 hover:text-orange-800"
                        >
                          Evolución
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );

  const renderNuevoPaciente = () => (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Registro de Nuevo Paciente</h2>
        <form onSubmit={handleCrearPaciente} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-700 font-medium mb-2">DNI</label>
              <input
                type="text"
                required
                value={nuevoPaciente.dni}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, dni: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Fecha de Nacimiento</label>
              <input
                type="date"
                required
                value={nuevoPaciente.fechaNacimiento}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, fechaNacimiento: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Nombre</label>
              <input
                type="text"
                required
                value={nuevoPaciente.nombre}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, nombre: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Apellido</label>
              <input
                type="text"
                required
                value={nuevoPaciente.apellido}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, apellido: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Edad</label>
              <input
                type="number"
                required
                value={nuevoPaciente.edad}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, edad: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Teléfono</label>
              <input
                type="tel"
                required
                value={nuevoPaciente.telefono}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, telefono: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Correo</label>
              <input
                type="email"
                required
                value={nuevoPaciente.correo}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, correo: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Dirección</label>
              <input
                type="text"
                required
                value={nuevoPaciente.direccion}
                onChange={(e) => setNuevoPaciente({...nuevoPaciente, direccion: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="flex space-x-4">
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium"
            >
              Registrar Paciente
            </button>
            <button
              type="button"
              onClick={() => setCurrentView('pacientes')}
              className="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-400 font-medium"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const renderNuevaCita = () => (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Agendar Nueva Cita</h2>
        <form onSubmit={handleCrearCita} className="space-y-4">
          <div>
            <label className="block text-gray-700 font-medium mb-2">Paciente</label>
            <select
              required
              value={nuevaCita.pacienteId}
              onChange={(e) => setNuevaCita({...nuevaCita, pacienteId: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Seleccionar paciente</option>
              {pacientes.map(p => (
                <option key={p.id} value={p.id}>{p.nombre} {p.apellido} - DNI: {p.dni}</option>
              ))}
            </select>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-700 font-medium mb-2">Fecha</label>
              <input
                type="date"
                required
                value={nuevaCita.fecha}
                onChange={(e) => setNuevaCita({...nuevaCita, fecha: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">Hora</label>
              <select
                required
                value={nuevaCita.hora}
                onChange={(e) => setNuevaCita({...nuevaCita, hora: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Seleccionar hora</option>
                <option value="09:00">09:00 AM</option>
                <option value="10:00">10:00 AM</option>
                <option value="11:00">11:00 AM</option>
                <option value="14:00">02:00 PM</option>
                <option value="15:00">03:00 PM</option>
                <option value="16:00">04:00 PM</option>
                <option value="17:00">05:00 PM</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-gray-700 font-medium mb-2">Motivo de la consulta</label>
            <textarea
              required
              value={nuevaCita.motivo}
              onChange={(e) => setNuevaCita({...nuevaCita, motivo: e.target.value})}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex space-x-4">
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium"
            >
              Agendar Cita
            </button>
            <button
              type="button"
              onClick={() => setCurrentView('dashboard')}
              className="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-400 font-medium"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const renderHistoriaClinica = () => (
    <div className="max-w-5xl mx-auto">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex justify-between items-start mb-6">
          <LogoDentSalud />
          <button
            onClick={() => setCurrentView('pacientes')}
            className="text-blue-600 hover:text-blue-800 mt-4"
          >
            Volver a Pacientes
          </button>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-6">HISTORIA CLÍNICA</h2>

        {selectedPaciente && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Número de Historia Clínica</label>
                <input
                  type="text"
                  value={historiaClinica.numeroHistoria}
                  onChange={(e) => setHistoriaClinica({...historiaClinica, numeroHistoria: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fecha de Apertura</label>
                <input
                  type="date"
                  value={historiaClinica.fechaApertura}
                  onChange={(e) => setHistoriaClinica({...historiaClinica, fechaApertura: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-bold text-lg mb-4">Datos del Paciente</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Paciente</p>
                  <p className="font-medium">{selectedPaciente.nombre} {selectedPaciente.apellido}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Fecha de Nacimiento</p>
                  <p className="font-medium">{selectedPaciente.fechaNacimiento}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Edad</p>
                  <p className="font-medium">{selectedPaciente.edad} años</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">DNI</p>
                  <p className="font-medium">{selectedPaciente.dni}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Teléfono</p>
                  <p className="font-medium">{selectedPaciente.telefono}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Correo Electrónico</p>
                  <p className="font-medium">{selectedPaciente.correo}</p>
                </div>
                <div className="md:col-span-3">
                  <p className="text-sm text-gray-500">Domicilio</p>
                  <p className="font-medium">{selectedPaciente.direccion}</p>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Motivo de Consulta</label>
              <textarea
                rows={2}
                value={historiaClinica.motivoConsulta}
                onChange={(e) => setHistoriaClinica({...historiaClinica, motivoConsulta: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Describir el motivo de la consulta"
              />
            </div>

            <div>
              <p className="text-sm text-gray-500 mb-1">Odontólogo Tratante</p>
              <p className="font-medium">Dr. Miler</p>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-bold text-lg mb-4 text-green-700">ANTECEDENTES</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">1. Patológicos</label>
                  <textarea
                    rows={2}
                    value={historiaClinica.patologicos}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, patologicos: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Diabetes, hipertensión, etc."
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">2. Fisiológicos en mujeres Gestantes</label>
                    <div className="flex space-x-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="gestante"
                          value="SI"
                          checked={historiaClinica.gestante === 'SI'}
                          onChange={(e) => setHistoriaClinica({...historiaClinica, gestante: e.target.value})}
                          className="mr-2"
                        />
                        SI
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="gestante"
                          value="NO"
                          checked={historiaClinica.gestante === 'NO'}
                          onChange={(e) => setHistoriaClinica({...historiaClinica, gestante: e.target.value})}
                          className="mr-2"
                        />
                        NO
                      </label>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">E.G. (Semanas de Gestación)</label>
                    <input
                      type="number"
                      value={historiaClinica.semanasGestacion}
                      onChange={(e) => setHistoriaClinica({...historiaClinica, semanasGestacion: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">3. Farmacológicos - Mediación actual</label>
                  <textarea
                    rows={2}
                    value={historiaClinica.farmacologicos}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, farmacologicos: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Medicamentos que toma actualmente"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">4. Alérgico - Algún Medicamento</label>
                  <textarea
                    rows={2}
                    value={historiaClinica.alergias}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, alergias: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Penicilina, anestesia, etc."
                  />
                </div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-bold text-lg mb-4 text-green-700">EXAMEN MÉDICO</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">a. Cuello</label>
                  <input
                    type="text"
                    value={historiaClinica.cuello}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, cuello: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">b. ATM</label>
                  <input
                    type="text"
                    value={historiaClinica.atm}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, atm: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">c. Mucosa Yugal</label>
                  <input
                    type="text"
                    value={historiaClinica.mucosaYugal}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, mucosaYugal: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">d. Paladar duro y blanco</label>
                  <input
                    type="text"
                    value={historiaClinica.paladar}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, paladar: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">e. Lengua</label>
                  <input
                    type="text"
                    value={historiaClinica.lengua}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, lengua: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">f. Piso de Boca</label>
                  <input
                    type="text"
                    value={historiaClinica.pisoBoca}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, pisoBoca: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">g. Gingiva</label>
                  <input
                    type="text"
                    value={historiaClinica.gingiva}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, gingiva: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">h. Análisis de oclusión</label>
                  <input
                    type="text"
                    value={historiaClinica.analisisOclusion}
                    onChange={(e) => setHistoriaClinica({...historiaClinica, analisisOclusion: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex space-x-4 print-hide">
              <button
                onClick={handleGuardarHistoriaClinica}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center space-x-2"
              >
                <Save className="w-5 h-5" />
                <span>Guardar Historia Clínica</span>
              </button>
              <button
                onClick={handleImprimirHistoria}
                className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium flex items-center justify-center space-x-2"
              >
                <Printer className="w-5 h-5" />
                <span>Imprimir</span>
              </button>
            </div>

            <FooterFicha />
          </div>
        )}
      </div>
    </div>
  );

  const renderPresupuesto = () => {
    const calcularTotal = () => {
      return tratamientosPresupuesto.reduce((sum, t) => sum + (t.cantidad * t.precioUnitario), 0);
    };

    const agregarTratamiento = (nombre: string) => {
      const existe = tratamientosPresupuesto.find(t => t.nombre === nombre);
      if (!existe) {
        setTratamientosPresupuesto([...tratamientosPresupuesto, {
          nombre,
          cantidad: 1,
          precioUnitario: 0
        }]);
      }
    };

    return (
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start mb-6">
            <LogoDentSalud />
            <button
              onClick={() => setCurrentView('pacientes')}
              className="text-blue-600 hover:text-blue-800 mt-4"
            >
              Volver a Pacientes
            </button>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-6">PRESUPUESTO DE TRATAMIENTOS</h2>

          {selectedPaciente && (
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-bold text-lg">Paciente: {selectedPaciente.nombre} {selectedPaciente.apellido}</h3>
                <p className="text-gray-600">DNI: {selectedPaciente.dni}</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-bold text-lg mb-4 text-green-700">TRATAMIENTOS</h3>

                <div className="mb-4 print-hide">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Agregar Tratamiento</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    onChange={(e) => {
                      if (e.target.value) {
                        agregarTratamiento(e.target.value);
                        e.target.value = '';
                      }
                    }}
                  >
                    <option value="">Seleccionar tratamiento...</option>
                    {catalogoTratamientos.map((cat) => (
                      <option key={cat.nombre} value={cat.nombre}>{cat.nombre}</option>
                    ))}
                  </select>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead className="bg-green-50">
                      <tr>
                        <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">TRATAMIENTOS</th>
                        <th className="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">CANTIDAD</th>
                        <th className="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">P/U</th>
                        <th className="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">TOTAL</th>
                        <th className="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Acción</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tratamientosPresupuesto.map((tratamiento, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2">{tratamiento.nombre}</td>
                          <td className="border border-gray-300 px-4 py-2">
                            <input
                              type="number"
                              min="1"
                              value={tratamiento.cantidad}
                              onChange={(e) => {
                                const newTratamientos = [...tratamientosPresupuesto];
                                newTratamientos[index].cantidad = parseInt(e.target.value) || 1;
                                setTratamientosPresupuesto(newTratamientos);
                              }}
                              className="w-20 px-2 py-1 border border-gray-300 rounded text-center"
                            />
                          </td>
                          <td className="border border-gray-300 px-4 py-2">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={tratamiento.precioUnitario}
                              onChange={(e) => {
                                const newTratamientos = [...tratamientosPresupuesto];
                                newTratamientos[index].precioUnitario = parseFloat(e.target.value) || 0;
                                setTratamientosPresupuesto(newTratamientos);
                              }}
                              className="w-24 px-2 py-1 border border-gray-300 rounded text-right"
                              placeholder="0.00"
                            />
                          </td>
                          <td className="border border-gray-300 px-4 py-2 text-right font-medium">
                            S/ {(tratamiento.cantidad * tratamiento.precioUnitario).toFixed(2)}
                          </td>
                          <td className="border border-gray-300 px-4 py-2 text-center">
                            <button
                              onClick={() => {
                                setTratamientosPresupuesto(tratamientosPresupuesto.filter((_, i) => i !== index));
                              }}
                              className="text-red-600 hover:text-red-800 text-sm"
                            >
                              Eliminar
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50">
                      <tr>
                        <td colSpan={3} className="border border-gray-300 px-4 py-3 text-right font-bold">TOTAL S/</td>
                        <td className="border border-gray-300 px-4 py-3 text-right font-bold text-lg text-green-700">
                          S/ {calcularTotal().toFixed(2)}
                        </td>
                        <td className="border border-gray-300"></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              <div className="flex space-x-4 print-hide">
                <button
                  onClick={handleGuardarPresupuesto}
                  className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>Guardar Presupuesto</span>
                </button>
                <button
                  onClick={handleImprimirPresupuesto}
                  className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium flex items-center justify-center space-x-2"
                >
                  <Printer className="w-5 h-5" />
                  <span>Imprimir Presupuesto</span>
                </button>
              </div>

              <FooterFicha />
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderEvolucion = () => {
    const agregarEvolucion = () => {
      if (nuevoRegistroEvolucion.fecha && nuevoRegistroEvolucion.tratamiento && nuevoRegistroEvolucion.importe) {
        setEvolucionPaciente([...evolucionPaciente, {
          fecha: nuevoRegistroEvolucion.fecha,
          tratamiento: nuevoRegistroEvolucion.tratamiento,
          importe: parseFloat(nuevoRegistroEvolucion.importe),
          firma: nuevoRegistroEvolucion.firma
        }]);
        setNuevoRegistroEvolucion({
          fecha: '',
          tratamiento: '',
          importe: '',
          firma: 'Dr. Miler'
        });
      }
    };

    return (
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start mb-6">
            <LogoDentSalud />
            <button
              onClick={() => setCurrentView('pacientes')}
              className="text-blue-600 hover:text-blue-800 mt-4"
            >
              Volver a Pacientes
            </button>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-6">EVOLUCIÓN DEL TRATAMIENTO</h2>

          {selectedPaciente && (
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-bold text-lg">Paciente: {selectedPaciente.nombre} {selectedPaciente.apellido}</h3>
                <p className="text-gray-600">DNI: {selectedPaciente.dni}</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 print-hide">
                <h3 className="font-bold text-lg mb-4">Agregar Nuevo Registro</h3>
                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
                    <input
                      type="date"
                      value={nuevoRegistroEvolucion.fecha}
                      onChange={(e) => setNuevoRegistroEvolucion({...nuevoRegistroEvolucion, fecha: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Tratamiento Realizado</label>
                    <input
                      type="text"
                      value={nuevoRegistroEvolucion.tratamiento}
                      onChange={(e) => setNuevoRegistroEvolucion({...nuevoRegistroEvolucion, tratamiento: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Descripción del tratamiento"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Importe</label>
                    <input
                      type="number"
                      step="0.01"
                      value={nuevoRegistroEvolucion.importe}
                      onChange={(e) => setNuevoRegistroEvolucion({...nuevoRegistroEvolucion, importe: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                <button
                  onClick={agregarEvolucion}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
                >
                  <Plus className="w-5 h-5" />
                  <span>Agregar Registro</span>
                </button>
              </div>

              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-bold text-lg mb-4 text-green-700">HISTORIAL DE EVOLUCIÓN</h3>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead className="bg-green-50">
                      <tr>
                        <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">FECHA</th>
                        <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">TRATAMIENTO REALIZADO</th>
                        <th className="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">IMPORTE</th>
                        <th className="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">FIRMA</th>
                      </tr>
                    </thead>
                    <tbody>
                      {evolucionPaciente.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="border border-gray-300 px-4 py-8 text-center text-gray-500">
                            No hay registros de evolución
                          </td>
                        </tr>
                      ) : (
                        evolucionPaciente.map((registro, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="border border-gray-300 px-4 py-2">{registro.fecha}</td>
                            <td className="border border-gray-300 px-4 py-2">{registro.tratamiento}</td>
                            <td className="border border-gray-300 px-4 py-2 text-right">S/ {registro.importe.toFixed(2)}</td>
                            <td className="border border-gray-300 px-4 py-2 text-center">{registro.firma}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                    {evolucionPaciente.length > 0 && (
                      <tfoot className="bg-gray-50">
                        <tr>
                          <td colSpan={2} className="border border-gray-300 px-4 py-3 text-right font-bold">TOTAL PAGADO:</td>
                          <td className="border border-gray-300 px-4 py-3 text-right font-bold text-lg text-green-700">
                            S/ {evolucionPaciente.reduce((sum, r) => sum + r.importe, 0).toFixed(2)}
                          </td>
                          <td className="border border-gray-300"></td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>

              <div className="flex space-x-4 print-hide">
                <button
                  onClick={handleImprimirEvolucion}
                  className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium flex items-center justify-center space-x-2"
                >
                  <Printer className="w-5 h-5" />
                  <span>Imprimir Evolución</span>
                </button>
              </div>

              <FooterFicha />
            </div>
          )}
        </div>
      </div>
    );
  };

  const DienteComponent = ({ numero, onClick }: { numero: number; onClick: () => void }) => {
    return (
      <div className="flex flex-col items-center">
        <svg
          width="30"
          height="40"
          viewBox="0 0 30 40"
          className="cursor-pointer hover:opacity-75"
          onClick={onClick}
        >
          {/* Diente simplificado */}
          <path
            d="M15 2 C10 2, 8 5, 8 10 L8 25 C8 30, 10 38, 15 38 C20 38, 22 30, 22 25 L22 10 C22 5, 20 2, 15 2 Z"
            fill="white"
            stroke="#4B5563"
            strokeWidth="1.5"
          />
          {/* Corona del diente */}
          <ellipse cx="15" cy="12" rx="6" ry="5" fill="white" stroke="#4B5563" strokeWidth="1.5" />
        </svg>
      </div>
    );
  };

  const renderOdontograma = () => {
    const handleToothClick = (numero: number) => {
      setSelectedTooth(numero);
      // Aquí puedes agregar lógica para marcar diagnósticos
    };

    return (
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start mb-6">
            <LogoDentSalud />
            <button
              onClick={() => setCurrentView('pacientes')}
              className="text-blue-600 hover:text-blue-800 mt-4"
            >
              Volver a Pacientes
            </button>
          </div>

          {selectedPaciente && (
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-bold text-lg">Paciente: {selectedPaciente.nombre} {selectedPaciente.apellido}</h3>
                <p className="text-gray-600">DNI: {selectedPaciente.dni}</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6">
                <h3 className="font-bold text-2xl mb-6 text-center text-green-700">ODONTODIAGRAMA</h3>

                {/* Dentición Permanente */}
                <div className="mb-12">
                  <h4 className="text-center font-semibold mb-4 text-gray-700">Dentición Permanente (Adulto)</h4>

                  {/* Arcada Superior */}
                  <div className="mb-8">
                    {/* Casillas superiores */}
                    <div className="flex justify-center mb-2">
                      {[...Array(16)].map((_, i) => (
                        <div key={i} className="w-8 h-6 border border-gray-300 mx-0.5"></div>
                      ))}
                    </div>

                    {/* Números superiores */}
                    <div className="flex justify-center mb-2">
                      {[18, 17, 16, 15, 14, 13, 12, 11].map(num => (
                        <div key={num} className="w-8 text-center text-xs font-medium text-gray-700 mx-0.5">{num}</div>
                      ))}
                      {[21, 22, 23, 24, 25, 26, 27, 28].map(num => (
                        <div key={num} className="w-8 text-center text-xs font-medium text-gray-700 mx-0.5">{num}</div>
                      ))}
                    </div>

                    {/* Dientes superiores */}
                    <div className="flex justify-center">
                      {[18, 17, 16, 15, 14, 13, 12, 11].map(num => (
                        <div key={num} className="mx-0.5" onClick={() => handleToothClick(num)}>
                          <DienteComponent numero={num} onClick={() => handleToothClick(num)} />
                        </div>
                      ))}
                      <div className="w-8"></div>
                      {[21, 22, 23, 24, 25, 26, 27, 28].map(num => (
                        <div key={num} className="mx-0.5" onClick={() => handleToothClick(num)}>
                          <DienteComponent numero={num} onClick={() => handleToothClick(num)} />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Dentición Decidua (Infantil) */}
                  <div className="mb-8">
                    <div className="flex justify-center">
                      {[55, 54, 53, 52, 51].map(num => (
                        <div key={num} className="mx-1">
                          <div className="text-xs text-center text-green-600 font-medium mb-1">{num}</div>
                          <div
                            className="w-6 h-6 border border-green-400 rounded-full bg-green-50 cursor-pointer hover:bg-green-100"
                            onClick={() => handleToothClick(num)}
                          ></div>
                        </div>
                      ))}
                      <div className="w-8"></div>
                      {[61, 62, 63, 64, 65].map(num => (
                        <div key={num} className="mx-1">
                          <div className="text-xs text-center text-green-600 font-medium mb-1">{num}</div>
                          <div
                            className="w-6 h-6 border border-green-400 rounded-full bg-green-50 cursor-pointer hover:bg-green-100"
                            onClick={() => handleToothClick(num)}
                          ></div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Línea central */}
                  <div className="border-t-2 border-green-600 my-6"></div>

                  {/* Dentición Decidua Inferior */}
                  <div className="mb-8">
                    <div className="flex justify-center">
                      {[85, 84, 83, 82, 81].map(num => (
                        <div key={num} className="mx-1">
                          <div
                            className="w-6 h-6 border border-green-400 rounded-full bg-green-50 cursor-pointer hover:bg-green-100"
                            onClick={() => handleToothClick(num)}
                          ></div>
                          <div className="text-xs text-center text-green-600 font-medium mt-1">{num}</div>
                        </div>
                      ))}
                      <div className="w-8"></div>
                      {[71, 72, 73, 74, 75].map(num => (
                        <div key={num} className="mx-1">
                          <div
                            className="w-6 h-6 border border-green-400 rounded-full bg-green-50 cursor-pointer hover:bg-green-100"
                            onClick={() => handleToothClick(num)}
                          ></div>
                          <div className="text-xs text-center text-green-600 font-medium mt-1">{num}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Arcada Inferior */}
                  <div>
                    {/* Dientes inferiores */}
                    <div className="flex justify-center mb-2">
                      {[48, 47, 46, 45, 44, 43, 42, 41].map(num => (
                        <div key={num} className="mx-0.5" onClick={() => handleToothClick(num)}>
                          <DienteComponent numero={num} onClick={() => handleToothClick(num)} />
                        </div>
                      ))}
                      <div className="w-8"></div>
                      {[31, 32, 33, 34, 35, 36, 37, 38].map(num => (
                        <div key={num} className="mx-0.5" onClick={() => handleToothClick(num)}>
                          <DienteComponent numero={num} onClick={() => handleToothClick(num)} />
                        </div>
                      ))}
                    </div>

                    {/* Números inferiores */}
                    <div className="flex justify-center mb-2">
                      {[48, 47, 46, 45, 44, 43, 42, 41].map(num => (
                        <div key={num} className="w-8 text-center text-xs font-medium text-gray-700 mx-0.5">{num}</div>
                      ))}
                      {[31, 32, 33, 34, 35, 36, 37, 38].map(num => (
                        <div key={num} className="w-8 text-center text-xs font-medium text-gray-700 mx-0.5">{num}</div>
                      ))}
                    </div>

                    {/* Casillas inferiores */}
                    <div className="flex justify-center">
                      {[...Array(16)].map((_, i) => (
                        <div key={i} className="w-8 h-6 border border-gray-300 mx-0.5"></div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Diagnóstico seleccionado */}
                {selectedTooth && (
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <h4 className="font-semibold mb-2">Pieza dental seleccionada: {selectedTooth}</h4>
                    <div className="grid grid-cols-2 gap-2">
                      <button className="px-3 py-2 bg-red-500 text-white rounded hover:bg-red-600 text-sm">
                        Marcar Caries
                      </button>
                      <button className="px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm">
                        Marcar Obturado
                      </button>
                      <button className="px-3 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 text-sm">
                        Marcar Ausente
                      </button>
                      <button className="px-3 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 text-sm">
                        Marcar Fracturado
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-bold mb-3">DIAGNÓSTICO ESTOMATOLÓGICO CIE 10:</h3>
                <textarea
                  rows={3}
                  value={diagnosticoOdontograma}
                  onChange={(e) => setDiagnosticoOdontograma(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ingresar diagnóstico según CIE-10..."
                />
              </div>

              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <h3 className="font-bold mb-3">Leyenda de Diagnósticos</h3>
                <div className="grid md:grid-cols-4 gap-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 bg-red-500 rounded"></div>
                    <span className="text-sm">Caries</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 bg-blue-500 rounded"></div>
                    <span className="text-sm">Obturado/Curado</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 bg-gray-500 rounded"></div>
                    <span className="text-sm">Pieza Ausente</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 bg-yellow-500 rounded"></div>
                    <span className="text-sm">Fracturado</span>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4 print-hide">
                <button
                  onClick={handleGuardarOdontograma}
                  className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>Guardar Odontograma</span>
                </button>
                <button
                  onClick={handleImprimirOdontograma}
                  className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium flex items-center justify-center space-x-2"
                >
                  <Printer className="w-5 h-5" />
                  <span>Imprimir</span>
                </button>
              </div>

              <FooterFicha />
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Smile className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">DentSalud</h1>
                <p className="text-xs text-gray-500">Dr. Miler</p>
              </div>
            </div>
            <button className="flex items-center space-x-2 text-gray-700 hover:text-gray-900">
              <User className="w-5 h-5" />
              <span className="hidden md:inline">Dr. Miler</span>
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            <button
              onClick={() => setCurrentView('dashboard')}
              className={`flex items-center space-x-2 py-4 border-b-2 transition ${
                currentView === 'dashboard'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Home className="w-5 h-5" />
              <span>Dashboard</span>
            </button>
            <button
              onClick={() => setCurrentView('pacientes')}
              className={`flex items-center space-x-2 py-4 border-b-2 transition ${
                currentView === 'pacientes' || currentView === 'nuevo-paciente' || currentView === 'historia-clinica' || currentView === 'odontograma'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>Pacientes</span>
            </button>
            <button
              onClick={() => setCurrentView('nueva-cita')}
              className={`flex items-center space-x-2 py-4 border-b-2 transition ${
                currentView === 'nueva-cita'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span>Nueva Cita</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'dashboard' && renderDashboard()}
        {currentView === 'pacientes' && renderPacientes()}
        {currentView === 'nuevo-paciente' && renderNuevoPaciente()}
        {currentView === 'nueva-cita' && renderNuevaCita()}
        {currentView === 'historia-clinica' && renderHistoriaClinica()}
        {currentView === 'odontograma' && renderOdontograma()}
        {currentView === 'presupuesto' && renderPresupuesto()}
        {currentView === 'evolucion' && renderEvolucion()}
      </main>
    </div>
  );
}