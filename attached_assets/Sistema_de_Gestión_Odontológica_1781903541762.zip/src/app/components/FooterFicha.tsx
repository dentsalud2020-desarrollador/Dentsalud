import { Phone, MapPin } from 'lucide-react';

export function FooterFicha() {
  return (
    <div className="mt-8 pt-4 border-t border-gray-200 print:block hidden">
      <div className="flex justify-between items-center text-sm text-gray-600">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Phone className="w-4 h-4" />
            <span>044 - 637 622 / 997 054 525</span>
          </div>
          <div className="flex items-center space-x-2">
            <MapPin className="w-4 h-4" />
            <span>Av. El ejército N° 831 - 827 (a media cuadra de la UPN)</span>
          </div>
        </div>
        <div className="text-right">
          <p className="font-semibold">Centro DentSalud</p>
          <p>dentsalud_centro</p>
        </div>
      </div>
    </div>
  );
}
