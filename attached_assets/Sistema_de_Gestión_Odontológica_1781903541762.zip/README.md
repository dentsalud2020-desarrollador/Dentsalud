
  # Sistema de Gestión Odontológica

  This is a code bundle for Sistema de Gestión Odontológica. The original project is available at https://www.figma.com/design/A6vxR2Sg1SGqvgt2dayYU1/Sistema-de-Gesti%C3%B3n-Odontol%C3%B3gica.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  