import { Smile } from 'lucide-react';

export function LogoDentSalud() {
  return (
    <div className="flex items-center justify-center mb-6">
      <div className="flex items-center space-x-3">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-4 border-green-500 flex items-center justify-center bg-white">
            <Smile className="w-10 h-10 text-blue-600" />
          </div>
        </div>
        <div>
          <h1 className="text-3xl font-bold">
            <span className="text-green-600">Dent</span>
            <span className="text-blue-600">Salud</span>
          </h1>
          <p className="text-xs text-gray-600 uppercase tracking-wide">
            Tu Centro de Armonía Dentofacial
          </p>
        </div>
      </div>
    </div>
  );
}
